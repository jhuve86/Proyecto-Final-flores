package com.flowers.ordering.system;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrderingSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
